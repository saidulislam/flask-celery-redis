from project import create_app, ext_celery

app = create_app()
celery = ext_celery.celery

@app.route("/")
def hello_world():
    return "Flask is up!"


# to monitor the "project" directory for changes to any Python file 
# recursively. run_worker is a callback function that gets called 
# when a change occurs.
@app.cli.command("celery_worker")
def celery_worker():
    from watchgod import run_process
    import subprocess

    def run_worker():
        subprocess.call(
            ["celery", "-A", "app.celery", "worker", "--loglevel=info"]
        )

    run_process("./project", run_worker)
